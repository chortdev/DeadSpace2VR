@echo off
setlocal
if "%~1"=="" (
  echo Usage: install.bat "C:\path\to\Dead Space 2" [-WhatIf ^| -Uninstall] [-MigrateFrom "C:\old\Dead Space 2"]
  exit /b 2
)
set "GAME_DIR=%~1"
shift
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -GameDir "%GAME_DIR%" %*
exit /b %ERRORLEVEL%
