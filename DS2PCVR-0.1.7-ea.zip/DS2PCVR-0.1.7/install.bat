@echo off
setlocal
rem Usage: install.bat "C:\path\to\Dead Space 2" [-WhatIf | -Uninstall] [-MigrateFrom "C:\old\Dead Space 2"]
rem Double-clicked without arguments, it asks for the game folder and installs.
if not "%~1"=="" goto run
set "GAME_DIR="
set /p "GAME_DIR=Dead Space 2 folder (the one with deadspace2.exe): "
if not defined GAME_DIR exit /b 2
set "GAME_DIR=%GAME_DIR:"=%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -GameDir "%GAME_DIR%"
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%
:run
rem No SHIFT: it would also move %0 and break %~dp0.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -GameDir %*
exit /b %ERRORLEVEL%
