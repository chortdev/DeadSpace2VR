param(
    [Parameter(Mandatory=$true)][string]$GameDir,
    [string]$MigrateFrom,
    [switch]$WhatIf,
    [switch]$Uninstall
)

$ErrorActionPreference = 'Stop'
$pinnedExe = 'e13195d0cdd928e9bbb537b049b4aee0bb63e8ac1915af5bf166f745aea985ec'
$steamExe = 'f72f15b8a6aced7970569e66e4eaabf322a5fdd7b58e9030fdea268d770d1d7f'
# EA app build: the Steam code under another DRM wrapper, same DLL logic.
$eaExe = 'f9aa4811d06a18749064b5875ef091a1837d887b18deca9653aace796f0fd4e7'
$knownExe = @{ $pinnedExe = 'pinned'; $steamExe = 'steam'; $eaExe = 'ea' }
$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$game = (Resolve-Path -LiteralPath $GameDir).Path
$exe = Join-Path $game 'deadspace2.exe'
$marker = Join-Path $game 'ds2pcvr-installed.json'
$backupSuffix = '.ds2pcvr-backup'

function Get-Sha256([string]$Path) {
    $stream = [System.IO.File]::OpenRead($Path)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}

function Test-X86Pe([string]$Path) {
    $stream = [System.IO.File]::OpenRead($Path)
    $reader = New-Object System.IO.BinaryReader($stream)
    try {
        if ($reader.ReadUInt16() -ne 0x5a4d) { return $false }
        $stream.Position = 0x3c
        $peOffset = $reader.ReadUInt32()
        $stream.Position = $peOffset
        if ($reader.ReadUInt32() -ne 0x00004550) { return $false }
        $machine = $reader.ReadUInt16()
        $stream.Position = $peOffset + 24
        $magic = $reader.ReadUInt16()
        return ($machine -eq 0x014c -and $magic -eq 0x010b)
    } finally { $reader.Dispose(); $stream.Dispose() }
}

function Assert-GameClosed([string]$Directory) {
    $targetExe = [System.IO.Path]::GetFullPath((Join-Path $Directory 'deadspace2.exe'))
    try { $running = Get-CimInstance Win32_Process -Filter "Name='deadspace2.exe'" -ErrorAction Stop }
    catch { throw "Cannot determine whether this game directory is running: $($_.Exception.Message)" }
    foreach ($process in $running) {
        if (-not $process.ExecutablePath) { throw 'Cannot identify the executable path of a running Dead Space 2 process' }
        if ([System.IO.Path]::GetFullPath($process.ExecutablePath) -ieq $targetExe) {
            throw "Close Dead Space 2 running from $targetExe first"
        }
    }
}

function Set-IniValue([string]$Text, [string]$Key, [string]$Value) {
    $escaped = [regex]::Escape($Key)
    $lines = [regex]::Split($Text, '\r?\n')
    $inStereo = $false
    $section = -1
    $keyLine = -1
    for ($i = 0; $i -lt $lines.Length; $i++) {
        if ($lines[$i] -match '^\s*\[([^]]+)\]\s*$') {
            $inStereo = $Matches[1] -ieq 'stereo'
            if ($inStereo) { $section = $i }
        } elseif ($inStereo -and $lines[$i] -match ('^\s*' + $escaped + '\s*=')) {
            $keyLine = $i
        }
    }
    if ($keyLine -ge 0) { $lines[$keyLine] = "$Key=$Value" }
    elseif ($section -ge 0) {
        $before = @(); $after = @()
        if ($section -ge 0) { $before = @($lines[0..$section]) }
        if ($section + 1 -lt $lines.Length) { $after = @($lines[($section + 1)..($lines.Length - 1)]) }
        $lines = $before + @("$Key=$Value") + $after
    } else { $lines = @($lines) + @('[stereo]', "$Key=$Value") }
    return ($lines -join "`r`n")
}

function Get-IniValue([string]$Text, [string]$Key) {
    $escaped = [regex]::Escape($Key)
    $inStereo = $false
    foreach ($line in [regex]::Split($Text, '\r?\n')) {
        if ($line -match '^\s*\[([^]]+)\]\s*$') { $inStereo = $Matches[1] -ieq 'stereo'; continue }
        if ($inStereo -and $line -match ('^\s*' + $escaped + '\s*=\s*(.*?)\s*$')) { return $Matches[1] }
    }
    return ''
}

if ($Uninstall) {
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) { throw 'No DS2 PC VR ownership manifest found' }
    $owned = Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json
    if ($owned.schema -ne 2 -or -not $owned.files -or $owned.profile -notin @('pinned', 'steam', 'ea')) { throw 'Unsupported ownership manifest' }
    $ownedNames = @($owned.files.PSObject.Properties.Name | Sort-Object)
    $optionalOwned = @('ds2chest.bin', 'ds2reloadbuilder.bin', 'ds2hands.exe', 'ds2inertia.ini', 'dxvk_d3d9.dll', 'dxvk.conf')
    if (-not ($ownedNames -contains 'd3d9.dll') -or -not ($ownedNames -contains 'openvr_api.dll') -or
        @($ownedNames | Where-Object { $_ -notin (@('d3d9.dll', 'openvr_api.dll') + $optionalOwned) }).Count) { throw 'Ownership manifest names are invalid' }
    Assert-GameClosed $game
    foreach ($name in $owned.files.PSObject.Properties.Name) {
        $record = $owned.files.$name
        $target = Join-Path $game $name
        if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Owned file is missing: $name" }
        if ((Get-Sha256 $target) -ne $record.installed_sha256) { throw "Owned file changed since installation; leaving it and its backups untouched: $name" }
        if ($record.backup -ne "$name$backupSuffix") { throw "Ownership backup name is invalid: $name" }
        if ($record.previous_exists -and -not (Test-Path -LiteralPath (Join-Path $game $record.backup) -PathType Leaf)) {
            throw "Missing preserved file: $($record.backup)"
        }
        if ($record.previous_exists -and (Get-Sha256 (Join-Path $game $record.backup)) -ne $record.backup_sha256) { throw "Preserved file changed: $($record.backup)" }
    }
    if ($owned.config_backup_name) {
        if ($owned.config_backup_name -notmatch '^ds2stereo\.ini\.ds2pcvr-original-[0-9a-f]{32}\.ini$') { throw 'Configuration backup name is invalid' }
        if (-not (Test-Path -LiteralPath (Join-Path $game $owned.config_backup_name) -PathType Leaf)) { throw 'Original configuration backup is missing' }
        if ((Get-Sha256 (Join-Path $game $owned.config_backup_name)) -ne $owned.config_original_sha256) { throw 'Original configuration backup changed' }
    }
    if ($owned.log_dir -and -not $owned.log_dir.StartsWith($game, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Owned log directory is outside the game directory' }
    if ($WhatIf) { Write-Host "Would remove DS2 PC VR owned files from $game"; exit 0 }
    foreach ($name in $owned.files.PSObject.Properties.Name) {
        if ($name -eq 'ds2stereo.ini') { continue }
        $record = $owned.files.$name
        $target = Join-Path $game $name
        Remove-Item -LiteralPath $target -Force
        if ($record.previous_exists) { Move-Item -LiteralPath (Join-Path $game $record.backup) -Destination $target }
    }
    if ($owned.config_backup_name) {
        $config = Join-Path $game 'ds2stereo.ini'
        if (Test-Path -LiteralPath $config -PathType Leaf) {
            if ((Get-Sha256 $config) -ne $owned.config_installed_sha256) {
                $savedSettings = "ds2stereo.ini.ds2pcvr-saved-$([guid]::NewGuid().ToString('N')).ini"
                Move-Item -LiteralPath $config -Destination (Join-Path $game $savedSettings)
                Write-Host "Preserved edited VR settings as $savedSettings"
            } else { Remove-Item -LiteralPath $config -Force }
        }
        Move-Item -LiteralPath (Join-Path $game $owned.config_backup_name) -Destination $config
    }
    Remove-Item -LiteralPath $marker -Force
    Write-Host "DS2 PC VR removed from $game"
    exit 0
}

if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'deadspace2.exe is missing' }
if ($source.TrimEnd('\') -ieq $game.TrimEnd('\')) { throw 'These files are already in the game folder, so the mod is installed: start the game. install.bat is optional; to use it anyway, run it from the extracted DS2PCVR folder.' }
Assert-GameClosed $game
# Installing over an installed build updates it in place: the payload is
# replaced, while the first install's backups and ds2stereo.ini stay as they are.
$previous = $null
if (Test-Path -LiteralPath $marker) {
    $previous = Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json
    if ($previous.schema -ne 2 -or -not $previous.files) { throw 'Unsupported ownership manifest; uninstall the old build first' }
}
$actualExe = Get-Sha256 $exe
$profilePath = Join-Path $source 'profile.json'
if (-not (Test-Path -LiteralPath $profilePath -PathType Leaf)) { throw 'Package profile.json is missing' }
$profile = Get-Content -LiteralPath $profilePath -Raw | ConvertFrom-Json
if ($profile.schema -ne 1 -or $profile.profile -notin @('pinned', 'steam', 'ea')) { throw 'Unknown package profile' }
$expectedExe = switch ($profile.profile) { 'steam' { $steamExe } 'ea' { $eaExe } default { $pinnedExe } }
if ($actualExe -ne $expectedExe -and $knownExe.ContainsKey($actualExe)) {
    throw "This deadspace2.exe needs the -$($knownExe[$actualExe]) package, not -$($profile.profile)"
}
if (-not $knownExe.ContainsKey($actualExe)) {
    throw "This deadspace2.exe is not a version the mod supports (Steam, EA app, original retail; SHA-256 $actualExe). If it was patched (4GB/LAA patch, no-CD or other exe mods), restore the original: Steam -> Properties -> Installed Files -> Verify integrity, EA app -> Repair. Otherwise send this SHA-256 to the mod author."
}
if ($actualExe -ne $expectedExe -or $profile.exe_sha256 -ne $expectedExe) { throw 'Package profile does not match this executable SHA-256' }
if (-not $knownExe.ContainsKey($actualExe)) { throw 'Unsupported deadspace2.exe SHA-256' }
foreach ($name in @('install.ps1', 'install.bat')) {
    $path = Join-Path $source $name
    if (-not $profile.files.$name -or (Get-Sha256 $path) -ne $profile.files.$name) { throw "Package installer file SHA-256 mismatch: $name" }
}

$payload = @('d3d9.dll', 'openvr_api.dll', 'ds2chest.bin')
if ($profile.files.'dxvk_d3d9.dll') { $payload += 'dxvk_d3d9.dll' }
if ($profile.files.'dxvk.conf') { $payload += 'dxvk.conf' }
if ($profile.files.'ds2reloadbuilder.bin') { $payload += 'ds2reloadbuilder.bin' }
if ($profile.files.'ds2inertia.ini') { $payload += 'ds2inertia.ini' }
if ($profile.files.'ds2hands.exe') { $payload += 'ds2hands.exe' }
foreach ($name in $payload) {
    $path = Join-Path $source $name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Package file missing: $name" }
    if (($name.EndsWith('.dll') -or $name.EndsWith('.exe')) -and -not (Test-X86Pe $path)) { throw "Package file is not a PE32 x86 image: $name" }
    $expected = $profile.files.$name
    if (-not $expected -or (Get-Sha256 $path) -ne $expected) { throw "Package file SHA-256 mismatch: $name" }
}
$abiPath = Join-Path $source 'vr-settings-native-abi.json'
if (-not (Test-Path -LiteralPath $abiPath -PathType Leaf) -or
    (Get-Sha256 $abiPath) -ne $profile.files.'vr-settings-native-abi.json') {
    throw 'Package native-page ABI evidence is missing or has changed'
}
$abi = Get-Content -LiteralPath $abiPath -Raw | ConvertFrom-Json
if (@($abi.callbacks.PSObject.Properties).Count -ne 13 -or $abi.dll_sha256 -ne $profile.files.'d3d9.dll') {
    throw 'Package does not include the matching 13-callback x86 ABI report'
}
$packageIni = Join-Path $source 'ds2stereo.ini'
if (-not (Test-Path -LiteralPath $packageIni -PathType Leaf) -or
    (Get-Sha256 $packageIni) -ne $profile.files.'ds2stereo.ini' -or
    (Get-Content -LiteralPath $packageIni -Raw) -notmatch '(?im)^vr_settings_menu\s*=\s*on\s*$') {
    throw 'Package must include ds2stereo.ini with vr_settings_menu=on'
}
if ($profile.profile -eq 'steam' -and $actualExe -ne $steamExe) { throw 'Steam package identity mismatch' }

# Taught manual-reload profiles (0.1.11) follow the calibration rule below:
# copied only when the game folder has none, kept on uninstall.
$reloadProfiles = @(Get-ChildItem -LiteralPath $source -Filter 'ds2reload-*.profile' -File)
# Editable calibration belongs to the user, like a fresh ds2stereo.ini: copy a
# packaged default only when the game folder has none, keep it on uninstall.
$userCopies = [ordered]@{}
foreach ($name in @('ds2twohand.ini', 'ds2calibration.ini', 'ds2scene.ini')) {
    if (-not $profile.files.$name) { continue }
    $packaged = Join-Path $source $name
    if (-not (Test-Path -LiteralPath $packaged -PathType Leaf) -or (Get-Sha256 $packaged) -ne $profile.files.$name) {
        throw "Package calibration SHA-256 mismatch: $name"
    }
    $target = Join-Path $game $name
    if (Test-Path -LiteralPath $target -PathType Leaf) { continue }
    $userCopies[$target] = $packaged
    if ($MigrateFrom) {
        $calibrated = Join-Path (Resolve-Path -LiteralPath $MigrateFrom).Path $name
        if (Test-Path -LiteralPath $calibrated -PathType Leaf) { $userCopies[$target] = $calibrated }
    }
}
# 0.2.0: a profile still byte-equal to one shipped in 0.1.11-0.1.13 was never
# re-taught, so the newer packaged one replaces it (old copy kept beside it).
$shippedProfiles = @(
    'ed9d27715dca449dd08b5c039face53eeb6d9beca377336e4e2de6be93172b96', 'ebf2a71d4c72e608dc2547a40552cc5bf6314f9a40dd8bc202b60d08e554410b',
    '119264f8946b7afe1cbb3e697916b69f2c2131bf15f892769e64592fbd66956d', 'a10b987019493885c7cfd4288b2491a6e413c71e54518f47e90c192d9ffe09cb',
    'e4b1575b01b3a8514fbe9cf99136f5ae63e2406c05e76f618f05a23794ecc3ba', '676d3354c36e613e22a43b0935e24d35b95303382028b0f97b618f993ebbf166',
    '00f7f49da0e56d0e83521eebf1878bf4d383e7c0817f7ea4a9d0996b1fa7e95c')
$profileBackups = @{}
foreach ($packaged in $reloadProfiles) {
    $target = Join-Path $game $packaged.Name
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { $userCopies[$target] = $packaged.FullName; continue }
    $current = Get-Sha256 $target
    if ($current -ne (Get-Sha256 $packaged.FullName) -and $shippedProfiles -contains $current) {
        $userCopies[$target] = $packaged.FullName; $profileBackups[$target] = "$target.shipped-backup"
    }
}

$iniTarget = Join-Path $game 'ds2stereo.ini'
$migration = $null
if (Test-Path -LiteralPath $iniTarget -PathType Leaf) { $migration = $iniTarget }
elseif ($MigrateFrom) {
    $migration = Join-Path (Resolve-Path -LiteralPath $MigrateFrom).Path 'ds2stereo.ini'
    if (-not (Test-Path -LiteralPath $migration -PathType Leaf)) { throw 'MigrateFrom has no ds2stereo.ini' }
}
$backupFiles = @{}
$backupHashes = @{}
foreach ($name in $payload) {
    $target = Join-Path $game $name
    $backup = "$name$backupSuffix"
    if ($previous -and $previous.files.$name) { continue }
    if (Test-Path -LiteralPath (Join-Path $game $backup)) { throw "Existing backup blocks install: $backup" }
    $backupFiles[$name] = Test-Path -LiteralPath $target -PathType Leaf
    if ($backupFiles[$name]) { $backupHashes[$name] = Get-Sha256 $target }
}
$targetConfigExisted = (Test-Path -LiteralPath $iniTarget -PathType Leaf) -and -not $previous
$configBackupName = if ($targetConfigExisted) { "ds2stereo.ini.ds2pcvr-original-$([guid]::NewGuid().ToString('N')).ini" } else { $null }
if ($configBackupName -and (Test-Path -LiteralPath (Join-Path $game $configBackupName))) { throw 'Existing config backup blocks install' }
if ($previous -and -not (Test-Path -LiteralPath $iniTarget -PathType Leaf)) { throw 'ds2stereo.ini is missing; uninstall the old build first' }
if ($WhatIf) {
    if ($previous) { Write-Host "Would update the installed $($previous.profile) build in $game, keeping ds2stereo.ini" }
    Write-Host "Would install $($profile.profile) profile into $game"
    Write-Host "  executable SHA-256: $actualExe"
    Write-Host "  preserve calibrated configuration: $([bool]$migration)"
    exit 0
}

$moved = @()
$copied = @()
$updated = @()
$updateSuffix = '.ds2pcvr-update'
$configWasWritten = $false
$userWritten = @()
$logDir = if ($previous -and $previous.log_dir) { $previous.log_dir } else { Join-Path $game (Join-Path 'ds2pcvr-logs' ([guid]::NewGuid().ToString('N'))) }
$logDirCreated = $false
try {
    if ($targetConfigExisted) { Copy-Item -LiteralPath $iniTarget -Destination (Join-Path $game $configBackupName) }
    foreach ($name in $payload) {
        $target = Join-Path $game $name
        if ($previous -and $previous.files.$name) {
            if (Test-Path -LiteralPath "$target$updateSuffix") { Remove-Item -LiteralPath "$target$updateSuffix" -Force }
            if (Test-Path -LiteralPath $target -PathType Leaf) { Move-Item -LiteralPath $target -Destination "$target$updateSuffix"; $updated += $name }
        } elseif ($backupFiles[$name]) { Move-Item -LiteralPath $target -Destination "$target$backupSuffix"; $moved += $name }
        Copy-Item -LiteralPath (Join-Path $source $name) -Destination $target
        $copied += $name
    }
    foreach ($target in $userCopies.Keys) {
        if ($profileBackups[$target]) { Copy-Item -LiteralPath $target -Destination $profileBackups[$target] -Force }
        $userWritten += $target
        Copy-Item -LiteralPath $userCopies[$target] -Destination $target -Force
    }
    if (-not $previous) {
        $iniText = if ($migration) { Get-Content -LiteralPath $migration -Raw } else { Get-Content -LiteralPath $packageIni -Raw }
        if ($profile.profile -in @('steam', 'ea') -and -not (Get-IniValue $iniText 'offhand_reload_parallel')) {
            $iniText = Set-IniValue $iniText 'offhand_reload_parallel' '1'
        }
        # VR Settings, HUD and scene calibration are stored beside this file, else in
        # out_dir. out_dir is new on every install, so keep them in the game folder.
        if (-not (Get-IniValue $iniText 'hud_calibration_file')) {
            $iniText = Set-IniValue $iniText 'hud_calibration_file' (Join-Path $game 'ds2hud.ini')
        }
        $iniText = Set-IniValue $iniText 'out_dir' $logDir
        $iniText = Set-IniValue $iniText 'openvr_dll' (Join-Path $game 'openvr_api.dll')
        $realD3d9 = Get-IniValue $iniText 'real_d3d9'
        if ($realD3d9 -and -not [System.IO.Path]::IsPathRooted($realD3d9)) {
            if ($migration -and [System.IO.Path]::GetFullPath($migration) -ne [System.IO.Path]::GetFullPath($iniTarget)) {
                $legacyPath = Join-Path (Split-Path -Parent $migration) $realD3d9
                if (Test-Path -LiteralPath $legacyPath -PathType Leaf) { $realD3d9 = [System.IO.Path]::GetFullPath($legacyPath) }
                elseif ($backupFiles['d3d9.dll'] -and $realD3d9 -ieq 'd3d9.dll') { $realD3d9 = 'd3d9.dll.ds2pcvr-backup' }
                else { $realD3d9 = '' }
            } elseif ($realD3d9 -ieq 'd3d9.dll' -and $backupFiles['d3d9.dll']) {
                $realD3d9 = 'd3d9.dll.ds2pcvr-backup'
            } elseif ($realD3d9 -and -not (Test-Path -LiteralPath (Join-Path $game $realD3d9) -PathType Leaf)) {
                $realD3d9 = ''
            }
        }
        if (-not $realD3d9 -and $backupFiles['d3d9.dll']) { $realD3d9 = 'd3d9.dll.ds2pcvr-backup' }
        $iniText = Set-IniValue $iniText 'real_d3d9' $realD3d9
        New-Item -ItemType Directory -Path $logDir | Out-Null
        $logDirCreated = $true
        $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($iniTarget, $iniText, $utf8NoBom)
        $configWasWritten = $true
    }
    $records = [ordered]@{}
    foreach ($name in $payload) {
        $installed = Get-Sha256 (Join-Path $game $name)
        $old = if ($previous) { $previous.files.$name } else { $null }
        $records[$name] = if ($old) { [ordered]@{ installed_sha256 = $installed; previous_exists = [bool]$old.previous_exists; backup = $old.backup; backup_sha256 = $old.backup_sha256 } } else { [ordered]@{ installed_sha256 = $installed; previous_exists = [bool]$backupFiles[$name]; backup = "$name$backupSuffix"; backup_sha256 = $backupHashes[$name] } }
    }
    # An update keeps owning files the new package no longer ships, so uninstall still restores them.
    if ($previous) { foreach ($name in $previous.files.PSObject.Properties.Name) { if (-not $records.Contains($name)) { $records[$name] = $previous.files.$name } } }
    $manifest = if ($previous) {
        [ordered]@{ schema = 2; profile = $profile.profile; exe_sha256 = $actualExe; files = $records;
            config_installed_sha256 = $previous.config_installed_sha256; config_backup_name = $previous.config_backup_name;
            config_original_sha256 = $previous.config_original_sha256;
            config_had_target_original = $previous.config_had_target_original; log_dir = $previous.log_dir }
    } else {
        [ordered]@{ schema = 2; profile = $profile.profile; exe_sha256 = $actualExe; files = $records;
            config_installed_sha256 = Get-Sha256 $iniTarget; config_backup_name = $configBackupName;
            config_original_sha256 = if ($targetConfigExisted) { Get-Sha256 (Join-Path $game $configBackupName) } else { $null };
            config_had_target_original = [bool]$targetConfigExisted; log_dir = $logDir }
    }
    $manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $marker -Encoding ASCII
} catch {
    foreach ($target in $userWritten) { if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force } }
    foreach ($target in $profileBackups.Keys) {
        if (Test-Path -LiteralPath $profileBackups[$target]) { Move-Item -LiteralPath $profileBackups[$target] -Destination $target -Force }
    }
    if ($configWasWritten -and (Test-Path -LiteralPath $iniTarget)) { Remove-Item -LiteralPath $iniTarget -Force }
    if ($configBackupName -and (Test-Path -LiteralPath (Join-Path $game $configBackupName))) {
        if ($configWasWritten) { Move-Item -LiteralPath (Join-Path $game $configBackupName) -Destination $iniTarget }
        else { Remove-Item -LiteralPath (Join-Path $game $configBackupName) -Force }
    }
    if ($logDirCreated -and (Test-Path -LiteralPath $logDir) -and -not (Get-ChildItem -LiteralPath $logDir -Force | Select-Object -First 1)) { Remove-Item -LiteralPath $logDir -Force }
    foreach ($name in $copied) { $target = Join-Path $game $name; if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force } }
    foreach ($name in $moved) { $target = Join-Path $game $name; Move-Item -LiteralPath "$target$backupSuffix" -Destination $target }
    foreach ($name in $updated) { $target = Join-Path $game $name; Move-Item -LiteralPath "$target$updateSuffix" -Destination $target }
    throw
}
foreach ($name in $updated) { Remove-Item -LiteralPath (Join-Path $game "$name$updateSuffix") -Force }
if ($previous) { Write-Host "DS2 PC VR updated to the $($profile.profile) package in $game; ds2stereo.ini was kept; the log is $game\ds2stereo.log" } else { Write-Host "DS2 PC VR $($profile.profile) profile installed in $game; the log is $game\ds2stereo.log" }
